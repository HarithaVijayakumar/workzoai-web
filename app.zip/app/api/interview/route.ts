import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Speaker = "user" | "recruiter" | "candidate" | "assistant" | "system";

type TranscriptItem = {
  id?: string;
  speaker?: Speaker;
  role?: Speaker;
  text?: string;
  content?: string;
  timestamp?: string;
};

type MemoryItem = {
  id?: string;
  label: string;
  value: string;
  importance: "low" | "medium" | "high";
};

type InterviewSetup = {
  cvText?: string;
  jobDescription?: string;
  targetRole?: string;
  companyName?: string;
  country?: string;
  language?: string;
  recruiterPersonality?: string;
  recruiterStyle?: string;
  pressureMode?: string;
};

type LiveScore = {
  confidence: number;
  relevance: number;
  structure: number;
  evidence: number;
  clarity: number;
  overall: number;
};

type InterviewRequestBody = {
  mode?: "start" | "answer" | "next" | "score" | "finish";
  answer?: string;
  currentQuestion?: string;
  question?: string;
  setup?: InterviewSetup;
  transcript?: TranscriptItem[];
  recruiterMemory?: MemoryItem[];
  pressureLevel?: number;
  emotionState?: string;

  // Backward-compatible flat fields used by some older page versions.
  cvText?: string;
  jobDescription?: string;
  targetRole?: string;
  roleTitle?: string;
  companyName?: string;
  country?: string;
  language?: string;
  recruiterPersonality?: string;
  recruiterStyle?: string;
  pressureMode?: string;
};

type InterviewApiResponse = {
  ok: true;
  mode: string;
  recruiterReply: string;
  nextQuestion: string;
  interruption: string;
  contradictions: string[];
  recruiterMood: "Analytical" | "Skeptical" | "Interested" | "Neutral" | "Supportive";
  emotionState: "skeptical" | "interested" | "neutral" | "supportive" | "concerned";
  pressureLevel: number;
  liveScore: LiveScore;
  recruiterMemory: MemoryItem[];
  resultSnapshot: {
    overall: number;
    readiness: "Interview ready" | "Almost ready" | "Needs practice";
    recruiterTrust: number;
    strongestSignal: string;
    weakestSignal: string;
    nextAction: string;
  };
};

const recruiterQuestions = [
  "Tell me about yourself and keep it relevant to this role.",
  "What measurable impact did you create in your previous role?",
  "Why should we hire you for this position?",
  "Tell me about a difficult situation and how you handled it.",
  "What is your biggest professional weakness right now?",
  "Walk me through one achievement from your CV that is directly useful for this role.",
  "I see your background here. What makes you ready for this specific position?",
];

function randomQuestion() {
  return recruiterQuestions[Math.floor(Math.random() * recruiterQuestions.length)];
}

function cleanText(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function clamp(value: number, min = 0, max = 100) {
  if (Number.isNaN(value)) return min;
  return Math.max(min, Math.min(max, Math.round(value)));
}

function getSetup(body: InterviewRequestBody): Required<InterviewSetup> {
  return {
    cvText: cleanText(body.setup?.cvText ?? body.cvText),
    jobDescription: cleanText(body.setup?.jobDescription ?? body.jobDescription),
    targetRole: cleanText(body.setup?.targetRole ?? body.targetRole ?? body.roleTitle) || "General Role",
    companyName: cleanText(body.setup?.companyName ?? body.companyName) || "Target Company",
    country: cleanText(body.setup?.country ?? body.country) || "Global",
    language: cleanText(body.setup?.language ?? body.language) || "English",
    recruiterPersonality:
      cleanText(body.setup?.recruiterPersonality ?? body.recruiterPersonality) || "Analytical recruiter",
    recruiterStyle: cleanText(body.setup?.recruiterStyle ?? body.recruiterStyle) || "Balanced",
    pressureMode: cleanText(body.setup?.pressureMode ?? body.pressureMode) || "Realistic",
  };
}

function normalizeTranscript(items: TranscriptItem[] = []) {
  return items
    .map((item) => {
      const speaker = item.speaker ?? item.role ?? "system";
      const text = cleanText(item.text ?? item.content);
      return { speaker, text };
    })
    .filter((item) => item.text)
    .slice(-14);
}

function detectContradictions(answer: string, cvText: string, jobDescription = "") {
  const lower = answer.toLowerCase();
  const cv = cvText.toLowerCase();
  const jd = jobDescription.toLowerCase();
  const reference = `${cv}\n${jd}`;

  const warnings: string[] = [];

  if (lower.includes("berlin") && cv.includes("munich")) {
    warnings.push("Your answer mentioned Berlin, but your CV mentions Munich.");
  }

  if (lower.includes("my name is")) {
    const possibleName = lower.split("my name is")[1]?.trim()?.split(/\s+/)[0] || "";
    if (possibleName && cv && !cv.includes(possibleName)) {
      warnings.push("The recruiter detected a possible name mismatch with your CV.");
    }
  }

  const years = Array.from(new Set(lower.match(/\b(19|20)\d{2}\b/g) ?? []));
  years.forEach((year) => {
    if (reference && !reference.includes(year)) {
      warnings.push(`Your answer mentions ${year}, but that year is not visible in your CV or job context.`);
    }
  });

  const unsupportedClaims = [
    {
      test: /\bled\b|\bmanaged\b|\bowned\b|\bheaded\b/i,
      label: "leadership or ownership claim",
    },
    {
      test: /\b\d+%|\bincreased\b|\breduced\b|\bimproved\b|\bsaved\b/i,
      label: "measurable impact claim",
    },
    {
      test: /\bexpert\b|\badvanced\b|\bsenior\b/i,
      label: "seniority claim",
    },
  ];

  unsupportedClaims.forEach((claim) => {
    if (claim.test.test(answer) && reference && !claim.test.test(reference)) {
      warnings.push(`Your answer includes a ${claim.label} that is not clearly supported by the CV/JD context.`);
    }
  });

  return Array.from(new Set(warnings)).slice(0, 6);
}

function recruiterFollowup(answerText: string, contradictions: string[]) {
  const lower = answerText.toLowerCase();
  const wordCount = answerText.split(/\s+/).filter(Boolean).length;

  if (contradictions.length > 0) {
    return "Wait — let me stop you there. I heard something that does not fully match the CV or job context. Can you clarify it with a truthful example?";
  }

  if (
    !lower.includes("%") &&
    !lower.includes("improved") &&
    !lower.includes("reduced") &&
    !lower.includes("increased") &&
    !/\b\d+\b/.test(lower)
  ) {
    return "Let me stop you there — I still don’t understand the measurable impact.";
  }

  if (wordCount < 25) {
    return "That answer is too short. Can you give me a more structured example?";
  }

  if (lower.includes("maybe") || lower.includes("i think") || lower.includes("probably")) {
    return "You sound uncertain. Recruiters usually look for stronger ownership.";
  }

  return "Interesting. Give me one specific example with business impact.";
}

function scoreAnswer(answer: string, contradictions: string[]): LiveScore {
  const lower = answer.toLowerCase();
  const wordCount = answer.split(/\s+/).filter(Boolean).length;

  const hasMetric =
    /%|\b\d+\b|customers?|users?|tickets?|cases?|hours?|days?|weeks?|months?|revenue|cost|saved/i.test(answer);
  const hasImpactVerb = /\bimproved|reduced|increased|saved|resolved|built|automated|delivered|supported\b/i.test(answer);
  const hasStructure = /\bfirst|second|finally|situation|task|action|result|because|therefore|for example\b/i.test(answer);
  const uncertainty = /\bmaybe|i think|probably|not sure|kind of\b/i.test(answer);

  const evidence = clamp((hasMetric ? 78 : 48) + (hasImpactVerb ? 8 : 0) - contradictions.length * 8);
  const structure = clamp((wordCount > 40 ? 76 : 52) + (hasStructure ? 10 : 0));
  const confidence = clamp((uncertainty ? 45 : 74) - contradictions.length * 5);
  const relevance = clamp(72 + (hasImpactVerb ? 6 : 0) - contradictions.length * 6);
  const clarity = clamp((wordCount >= 25 && wordCount <= 140 ? 76 : 62) - (uncertainty ? 6 : 0));

  const overall = clamp((confidence + relevance + structure + evidence + clarity) / 5);

  return {
    confidence,
    evidence,
    structure,
    relevance,
    clarity,
    overall,
  };
}

function nextPressureLevel(answer: string, currentPressure: number, contradictions: string[]) {
  const weakAnswer = answer.length < 90 || contradictions.length > 0;
  if (weakAnswer) return clamp(currentPressure + 12, 0, 100);
  return clamp(currentPressure - 5, 0, 100);
}

function moodFromScore(score: LiveScore, pressureLevel: number, contradictions: string[]) {
  if (contradictions.length > 0 || pressureLevel > 70) {
    return {
      recruiterMood: "Skeptical" as const,
      emotionState: "skeptical" as const,
    };
  }

  if (score.overall > 78) {
    return {
      recruiterMood: "Interested" as const,
      emotionState: "interested" as const,
    };
  }

  if (score.overall < 58) {
    return {
      recruiterMood: "Analytical" as const,
      emotionState: "concerned" as const,
    };
  }

  return {
    recruiterMood: "Neutral" as const,
    emotionState: "neutral" as const,
  };
}

function buildMemory({
  existingMemory,
  followup,
  contradictions,
  score,
}: {
  existingMemory: MemoryItem[];
  followup: string;
  contradictions: string[];
  score: LiveScore;
}) {
  const newMemory: MemoryItem[] = [];

  contradictions.forEach((warning) => {
    newMemory.push({
      label: "CV contradiction detected",
      value: warning,
      importance: "high",
    });
  });

  newMemory.push({
    label: "Recent recruiter observation",
    value: followup,
    importance: score.overall < 65 ? "high" : "medium",
  });

  if (score.evidence < 60) {
    newMemory.push({
      label: "Weak evidence pattern",
      value: "Candidate needs stronger measurable proof and concrete business impact.",
      importance: "high",
    });
  }

  if (score.structure < 65) {
    newMemory.push({
      label: "Structure issue",
      value: "Candidate should answer using result-first or STAR structure.",
      importance: "medium",
    });
  }

  if (score.overall >= 78) {
    newMemory.push({
      label: "Strong answer signal",
      value: "Candidate gave a more relevant and confident answer.",
      importance: "medium",
    });
  }

  return [...existingMemory, ...newMemory].slice(-16);
}

function readinessFromScore(score: number): "Interview ready" | "Almost ready" | "Needs practice" {
  if (score >= 80) return "Interview ready";
  if (score >= 65) return "Almost ready";
  return "Needs practice";
}

function localEngine(body: InterviewRequestBody): InterviewApiResponse {
  const setup = getSetup(body);
  const mode = body.mode ?? "answer";
  const answer = cleanText(body.answer);
  const pressureLevel = clamp(Number(body.pressureLevel ?? 35), 0, 100);
  const existingMemory = Array.isArray(body.recruiterMemory) ? body.recruiterMemory : [];

  if (mode === "start" || !answer) {
    const firstQuestion =
      cleanText(body.currentQuestion ?? body.question) ||
      `I reviewed your CV for the ${setup.targetRole} role. Tell me about yourself and keep it relevant to this position.`;

    return {
      ok: true,
      mode,
      recruiterReply: "Good to meet you. I have your CV and the role context in front of me, so I’ll keep this close to a real interview.",
      nextQuestion: firstQuestion,
      interruption: "",
      contradictions: [],
      recruiterMood: "Analytical",
      emotionState: "neutral",
      pressureLevel,
      liveScore: {
        confidence: 65,
        relevance: 65,
        structure: 65,
        evidence: 65,
        clarity: 65,
        overall: 65,
      },
      recruiterMemory: existingMemory,
      resultSnapshot: {
        overall: 65,
        readiness: "Almost ready",
        recruiterTrust: 68,
        strongestSignal: "Interview started with CV/JD context.",
        weakestSignal: "No answer assessed yet.",
        nextAction: "Answer the first question with a result-first structure.",
      },
    };
  }

  const contradictions = detectContradictions(answer, setup.cvText, setup.jobDescription);
  const followup = recruiterFollowup(answer, contradictions);
  const liveScore = scoreAnswer(answer, contradictions);
  const updatedPressure = nextPressureLevel(answer, pressureLevel, contradictions);
  const mood = moodFromScore(liveScore, updatedPressure, contradictions);
  const recruiterMemory = buildMemory({
    existingMemory,
    followup,
    contradictions,
    score: liveScore,
  });

  const nextQuestion =
    liveScore.evidence < 60
      ? "What measurable result or business impact can you attach to that example?"
      : liveScore.structure < 65
        ? "Can you repeat that using Situation, Action, and Result in under 60 seconds?"
        : randomQuestion();

  const weakestSignal =
    contradictions.length > 0
      ? "Possible CV/JD contradiction"
      : liveScore.evidence < 60
        ? "Missing measurable proof"
        : liveScore.structure < 65
          ? "Answer structure"
          : "Needs deeper role relevance";

  const strongestSignal =
    liveScore.evidence >= 75
      ? "Used measurable evidence"
      : liveScore.confidence >= 72
        ? "Confident delivery"
        : "Stayed engaged with the recruiter question";

  return {
    ok: true,
    mode,
    recruiterReply: followup,
    nextQuestion,
    interruption: followup.startsWith("Let me stop you") || followup.startsWith("Wait") ? followup : "",
    contradictions,
    recruiterMood: mood.recruiterMood,
    emotionState: mood.emotionState,
    pressureLevel: updatedPressure,
    liveScore,
    recruiterMemory,
    resultSnapshot: {
      overall: liveScore.overall,
      readiness: readinessFromScore(liveScore.overall),
      recruiterTrust: clamp((liveScore.confidence + liveScore.relevance + liveScore.structure + liveScore.evidence) / 4 - contradictions.length * 6),
      strongestSignal,
      weakestSignal,
      nextAction:
        liveScore.overall >= 75
          ? "Continue with tougher follow-up questions."
          : "Retry this answer with result first, one example, and one truthful metric.",
    },
  };
}

function buildOpenAIPrompt(body: InterviewRequestBody, local: InterviewApiResponse) {
  const setup = getSetup(body);
  const answer = cleanText(body.answer);
  const currentQuestion = cleanText(body.currentQuestion ?? body.question);
  const transcript = normalizeTranscript(body.transcript);
  const memory = Array.isArray(body.recruiterMemory) ? body.recruiterMemory.slice(-8) : [];

  return `
You are WorkZo AI's Real Interview engine.

Product promise:
"Face a real interview before the real one."

Use the local deterministic analysis below, but improve it if needed.
Do not remove contradiction behavior, recruiter memory, scoring, pressure, or interruption behavior.

Role: ${setup.targetRole}
Company: ${setup.companyName}
Country/market: ${setup.country}
Language: ${setup.language}
Recruiter personality: ${setup.recruiterPersonality}
Recruiter style: ${setup.recruiterStyle}
Pressure mode: ${setup.pressureMode}

Current question:
${currentQuestion || "No active question."}

Candidate answer:
${answer || "No answer yet."}

Recent transcript:
${transcript.length ? transcript.map((item) => `${item.speaker}: ${item.text}`).join("\n") : "No transcript yet."}

Existing recruiter memory:
${memory.length ? memory.map((item) => `- ${item.label}: ${item.value} (${item.importance})`).join("\n") : "No memory yet."}

CV:
${setup.cvText.slice(0, 7000) || "No CV text provided."}

Job description:
${setup.jobDescription.slice(0, 7000) || "No JD provided."}

Local analysis to preserve:
${JSON.stringify(local, null, 2)}

Return ONLY valid JSON using this exact shape:
{
  "recruiterReply": "short realistic recruiter response",
  "nextQuestion": "next question",
  "interruption": "interruption line or empty string",
  "contradictions": ["max 6"],
  "recruiterMood": "Analytical | Skeptical | Interested | Neutral | Supportive",
  "emotionState": "skeptical | interested | neutral | supportive | concerned",
  "pressureLevel": 0,
  "liveScore": {
    "confidence": 0,
    "relevance": 0,
    "structure": 0,
    "evidence": 0,
    "clarity": 0,
    "overall": 0
  },
  "recruiterMemory": [
    {
      "label": "string",
      "value": "string",
      "importance": "low | medium | high"
    }
  ],
  "resultSnapshot": {
    "overall": 0,
    "readiness": "Interview ready | Almost ready | Needs practice",
    "recruiterTrust": 0,
    "strongestSignal": "string",
    "weakestSignal": "string",
    "nextAction": "string"
  }
}

Rules:
- Do not inflate scores.
- If the answer is vague or lacks proof, keep score below 70.
- If contradictions exist, recruiterMood should usually be Skeptical.
- Keep recruiterReply natural and short.
- Ask one question at a time.
`;
}

function parseJsonObject(text: string) {
  const cleaned = text
    .trim()
    .replace(/^```json/i, "")
    .replace(/^```/i, "")
    .replace(/```$/i, "")
    .trim();

  try {
    return JSON.parse(cleaned);
  } catch {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(cleaned.slice(start, end + 1));
    }

    throw new Error("OpenAI did not return valid JSON.");
  }
}

function normalizeMemory(items: unknown, fallback: MemoryItem[]) {
  if (!Array.isArray(items)) return fallback;

  return items
    .map((item) => {
      if (!item || typeof item !== "object") return null;
      const record = item as Partial<MemoryItem>;

      const label = cleanText(record.label);
      const value = cleanText(record.value);
      const importance =
        record.importance === "high" || record.importance === "medium" || record.importance === "low"
          ? record.importance
          : "medium";

      if (!label || !value) return null;

      return {
        label,
        value,
        importance,
      };
    })
    .filter(Boolean)
    .slice(-16) as MemoryItem[];
}

function mergeAiResponse(local: InterviewApiResponse, ai: Partial<InterviewApiResponse>): InterviewApiResponse {
  const liveScore = {
    confidence: clamp(Number(ai.liveScore?.confidence ?? local.liveScore.confidence)),
    relevance: clamp(Number(ai.liveScore?.relevance ?? local.liveScore.relevance)),
    structure: clamp(Number(ai.liveScore?.structure ?? local.liveScore.structure)),
    evidence: clamp(Number(ai.liveScore?.evidence ?? local.liveScore.evidence)),
    clarity: clamp(Number(ai.liveScore?.clarity ?? local.liveScore.clarity)),
    overall: clamp(Number(ai.liveScore?.overall ?? local.liveScore.overall)),
  };

  const recruiterMoodOptions = ["Analytical", "Skeptical", "Interested", "Neutral", "Supportive"] as const;
  const emotionOptions = ["skeptical", "interested", "neutral", "supportive", "concerned"] as const;

  const recruiterMood = recruiterMoodOptions.includes(ai.recruiterMood as any)
    ? (ai.recruiterMood as InterviewApiResponse["recruiterMood"])
    : local.recruiterMood;

  const emotionState = emotionOptions.includes(ai.emotionState as any)
    ? (ai.emotionState as InterviewApiResponse["emotionState"])
    : local.emotionState;

  const contradictions = Array.from(
    new Set([
      ...local.contradictions,
      ...(Array.isArray(ai.contradictions) ? ai.contradictions.map(cleanText).filter(Boolean) : []),
    ])
  ).slice(0, 6);

  return {
    ok: true,
    mode: local.mode,
    recruiterReply: cleanText(ai.recruiterReply) || local.recruiterReply,
    nextQuestion: cleanText(ai.nextQuestion) || local.nextQuestion,
    interruption: cleanText(ai.interruption) || local.interruption,
    contradictions,
    recruiterMood,
    emotionState,
    pressureLevel: clamp(Number(ai.pressureLevel ?? local.pressureLevel)),
    liveScore,
    recruiterMemory: normalizeMemory(ai.recruiterMemory, local.recruiterMemory),
    resultSnapshot: {
      overall: clamp(Number(ai.resultSnapshot?.overall ?? liveScore.overall)),
      readiness:
        ai.resultSnapshot?.readiness === "Interview ready" ||
        ai.resultSnapshot?.readiness === "Almost ready" ||
        ai.resultSnapshot?.readiness === "Needs practice"
          ? ai.resultSnapshot.readiness
          : readinessFromScore(liveScore.overall),
      recruiterTrust: clamp(Number(ai.resultSnapshot?.recruiterTrust ?? local.resultSnapshot.recruiterTrust)),
      strongestSignal: cleanText(ai.resultSnapshot?.strongestSignal) || local.resultSnapshot.strongestSignal,
      weakestSignal: cleanText(ai.resultSnapshot?.weakestSignal) || local.resultSnapshot.weakestSignal,
      nextAction: cleanText(ai.resultSnapshot?.nextAction) || local.resultSnapshot.nextAction,
    },
  };
}

export async function POST(request: NextRequest) {
  let body: InterviewRequestBody;

  try {
    body = (await request.json()) as InterviewRequestBody;
  } catch {
    return NextResponse.json(
      {
        ok: false,
        error: "Invalid JSON body.",
      },
      { status: 400 }
    );
  }

  const local = localEngine(body);

  if (!process.env.OPENAI_API_KEY) {
    return NextResponse.json({
      ...local,
      recruiterMemory: [
        ...local.recruiterMemory,
        {
          label: "AI fallback mode",
          value: "OPENAI_API_KEY is missing. WorkZo used the local interview engine.",
          importance: "medium",
        },
      ].slice(-16),
    });
  }

  try {
    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });

    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      temperature: 0.55,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "You are WorkZo AI's strict JSON-only recruiter simulation engine. Never return markdown, JSX, HTML, or prose outside JSON.",
        },
        {
          role: "user",
          content: buildOpenAIPrompt(body, local),
        },
      ],
    });

    const raw = completion.choices[0]?.message?.content || "{}";
    const ai = parseJsonObject(raw) as Partial<InterviewApiResponse>;
    const merged = mergeAiResponse(local, ai);

    return NextResponse.json(merged);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown OpenAI error.";

    return NextResponse.json({
      ...local,
      recruiterMemory: [
        ...local.recruiterMemory,
        {
          label: "OpenAI fallback",
          value: `OpenAI call failed, so WorkZo used the local interview engine. ${message}`,
          importance: "medium",
        },
      ].slice(-16),
    });
  }
}

export async function GET() {
  return NextResponse.json({
    ok: true,
    service: "WorkZo AI Interview API",
    status: "ready",
  });
}
