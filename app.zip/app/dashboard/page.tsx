"use client";

import Image from "next/image";
import Link from "next/link";
import { useInterviewStore } from "@/store/interviewStore";

function safeNumber(value: unknown, fallback = 0) {
  return typeof value === "number" && !Number.isNaN(value) ? value : fallback;
}

function readinessPercent(hasCv: boolean, hasRole: boolean, hasJob: boolean) {
  return [hasCv, hasRole, hasJob].filter(Boolean).length * 33;
}

export default function DashboardPage() {
  const {
    setup,
    liveScore,
    pressureLevel,
    emotionState,
    persistentPatterns,
    answerHistory,
    interruptionHistory,
    recruiterTrustHistory,
    transcript,
  } = useInterviewStore();

  const hasCv = Boolean(setup.cvText?.trim());
  const hasRole = Boolean(setup.targetRole?.trim());
  const hasJob = Boolean(setup.jobDescription?.trim());
  const readiness = Math.min(100, readinessPercent(hasCv, hasRole, hasJob));
  const finalTrust =
    recruiterTrustHistory.length > 0
      ? recruiterTrustHistory[recruiterTrustHistory.length - 1]
      : safeNumber(liveScore.overall);

  const topPatterns = persistentPatterns
    .slice()
    .sort((a, b) => b.count - a.count)
    .slice(0, 4);

  return (
    <main className="min-h-screen overflow-hidden bg-[#020817] text-white">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute left-1/2 top-[-180px] h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-blue-500/20 blur-[130px]" />
        <div className="absolute right-[-180px] top-[20%] h-[460px] w-[460px] rounded-full bg-cyan-400/10 blur-[130px]" />
        <div className="absolute bottom-[-240px] left-[-180px] h-[520px] w-[520px] rounded-full bg-purple-500/10 blur-[130px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-5 py-5 md:px-8">
        <header className="flex items-center justify-between rounded-3xl border border-white/10 bg-white/[0.06] px-4 py-3 shadow-2xl shadow-black/20 backdrop-blur-2xl md:px-5">
          <Link href="/" className="flex items-center gap-3">
            <Image
              src="/workzo_icon.png"
              alt="WorkZo AI"
              width={44}
              height={44}
              className="rounded-2xl"
              priority
            />

            <div>
              <p className="text-base font-semibold leading-tight">WorkZo AI</p>
              <p className="text-xs text-slate-400">Dashboard</p>
            </div>
          </Link>

          <nav className="hidden items-center gap-2 md:flex">
            <Link
              href="/onboarding"
              className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/10"
            >
              Change setup
            </Link>

            <Link
              href="/results"
              className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/10"
            >
              Results
            </Link>

            <Link
              href="/interview"
              className="rounded-2xl bg-blue-500 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/20 transition hover:bg-blue-400"
            >
              Start Interview
            </Link>
          </nav>

          <Link
            href="/interview"
            className="rounded-2xl bg-blue-500 px-4 py-2 text-sm font-semibold text-white md:hidden"
          >
            Start
          </Link>
        </header>

        <section className="mt-6 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-[38px] border border-white/10 bg-white/[0.06] p-6 shadow-2xl shadow-black/30 backdrop-blur-2xl md:p-8">
            <div className="inline-flex rounded-full border border-blue-400/20 bg-blue-500/10 px-4 py-2 text-sm text-blue-200">
              Your recruiter room is ready
            </div>

            <h1 className="mt-6 max-w-4xl text-4xl font-black leading-[1.05] tracking-tight md:text-6xl">
              Practice a real interview based on{" "}
              <span className="bg-gradient-to-r from-blue-400 via-cyan-300 to-white bg-clip-text text-transparent">
                your CV.
              </span>
            </h1>

            <p className="mt-5 max-w-2xl text-base leading-8 text-slate-300 md:text-lg">
              WorkZo uses your setup, CV, job description, recruiter style,
              pressure engine, and persistent memory to simulate a realistic
              interview experience.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                href="/interview"
                className="rounded-3xl bg-gradient-to-r from-blue-500 to-cyan-400 px-7 py-4 text-center text-base font-bold text-white shadow-2xl shadow-blue-500/25 transition hover:scale-[1.01] md:px-8 md:text-lg"
              >
                🎤 Enter Interview Room
              </Link>

              <Link
                href="/onboarding"
                className="rounded-3xl border border-white/10 bg-white/5 px-7 py-4 text-center text-base font-semibold text-white transition hover:bg-white/10 md:px-8 md:text-lg"
              >
                Update CV / Setup
              </Link>
            </div>

            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              {[
                ["Role", setup.targetRole || "Not selected"],
                ["Market", setup.targetMarket || "Global"],
                ["Recruiter", setup.recruiterPersonality || "Realistic"],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="rounded-3xl border border-white/10 bg-black/20 p-4"
                >
                  <p className="text-xs uppercase tracking-wide text-slate-500">
                    {label}
                  </p>
                  <p className="mt-2 line-clamp-2 text-sm font-semibold text-slate-100">
                    {value}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[38px] border border-white/10 bg-white/[0.06] p-5 shadow-2xl shadow-black/30 backdrop-blur-2xl md:p-6">
            <div className="rounded-[32px] border border-white/10 bg-[#07111f] p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-cyan-200">Simulation preview</p>
                  <h2 className="mt-1 text-2xl font-bold">
                    AI Recruiter Live
                  </h2>
                </div>

                <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-500/10 text-4xl">
                  👩🏻‍💼
                  <span className="absolute -right-1 -top-1 h-4 w-4 animate-pulse rounded-full bg-green-400 shadow-lg shadow-green-400/40" />
                </div>
              </div>

              <div className="mt-5 rounded-3xl border border-blue-400/20 bg-blue-500/10 p-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-blue-200">
                  Recruiter says
                </p>
                <p className="mt-3 text-lg font-semibold leading-8">
                  “I’ve reviewed your CV. Let’s test if your examples match the
                  role.”
                </p>
              </div>

              <div className="mt-5 h-3 overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-400"
                  style={{ width: `${Math.max(12, readiness)}%` }}
                />
              </div>

              <p className="mt-3 text-sm text-slate-400">
                Setup readiness: {readiness}%
              </p>
            </div>
          </div>
        </section>

        <section className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {[
            ["Overall score", `${safeNumber(liveScore.overall)}%`],
            ["Recruiter trust", `${safeNumber(finalTrust)}%`],
            ["Pressure level", `${safeNumber(pressureLevel)}%`],
            ["Emotion", emotionState || "neutral"],
          ].map(([label, value]) => (
            <div
              key={label}
              className="rounded-[30px] border border-white/10 bg-white/[0.05] p-5 backdrop-blur-xl"
            >
              <p className="text-sm text-slate-400">{label}</p>
              <p className="mt-3 text-3xl font-black capitalize">{value}</p>
            </div>
          ))}
        </section>

        <section className="mt-6 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="rounded-[32px] border border-white/10 bg-white/[0.05] p-6 backdrop-blur-xl">
            <h2 className="text-2xl font-bold">Long-term recruiter patterns</h2>
            <p className="mt-2 text-sm leading-6 text-slate-400">
              WorkZo tracks repeated habits across practice sessions on this
              device.
            </p>

            <div className="mt-5 space-y-3">
              {topPatterns.length > 0 ? (
                topPatterns.map((pattern) => (
                  <div
                    key={pattern.id}
                    className="rounded-2xl border border-white/10 bg-black/20 p-4"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <p className="font-semibold">{pattern.label}</p>
                      <span className="rounded-full bg-white/10 px-3 py-1 text-xs text-slate-300">
                        Seen {pattern.count}x
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="rounded-2xl bg-black/20 p-4 text-sm text-slate-400">
                  No long-term patterns yet. Complete a few answers to build
                  memory.
                </p>
              )}
            </div>
          </div>

          <div className="rounded-[32px] border border-white/10 bg-white/[0.05] p-6 backdrop-blur-xl">
            <h2 className="text-2xl font-bold">Recruiter trust trend</h2>

            <div className="mt-6 flex h-44 items-end gap-2 overflow-hidden">
              {(recruiterTrustHistory.length
                ? recruiterTrustHistory
                : [safeNumber(liveScore.overall)]
              )
                .slice(-20)
                .map((value, index) => (
                  <div
                    key={`${value}-${index}`}
                    className="flex flex-1 flex-col items-center justify-end"
                  >
                    <div
                      className={`w-full rounded-t-xl ${
                        value >= 75
                          ? "bg-green-400"
                          : value >= 55
                            ? "bg-yellow-400"
                            : "bg-red-400"
                      }`}
                      style={{ height: `${Math.max(12, value)}%` }}
                    />
                  </div>
                ))}
            </div>

            <div className="mt-5 grid grid-cols-3 gap-3 text-center text-sm">
              <div className="rounded-2xl bg-black/20 p-4">
                <p className="text-slate-500">Answers</p>
                <p className="mt-1 text-xl font-bold">
                  {answerHistory.length}
                </p>
              </div>
              <div className="rounded-2xl bg-black/20 p-4">
                <p className="text-slate-500">Interruptions</p>
                <p className="mt-1 text-xl font-bold">
                  {interruptionHistory.length}
                </p>
              </div>
              <div className="rounded-2xl bg-black/20 p-4">
                <p className="text-slate-500">Transcript</p>
                <p className="mt-1 text-xl font-bold">{transcript.length}</p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
