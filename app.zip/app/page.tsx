"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Brain,
  CheckCircle2,
  FileText,
  Gauge,
  Mic,
  ShieldCheck,
  Sparkles,
  UserRoundCheck,
  Zap,
} from "lucide-react";

import { useInterviewStore } from "@/store/interviewStore";

function hasContext(value: string | undefined) {
  return Boolean(value && value.trim().length > 0);
}

function safeCount(value: unknown) {
  return Array.isArray(value) ? value.length : 0;
}

export default function HomePage() {
  const { setup, persistentPatterns, answerHistory, recruiterTrustHistory } =
    useInterviewStore();

  const hasCv = hasContext(setup.cvText);
  const hasRole = hasContext(setup.targetRole);
  const hasJob = hasContext(setup.jobDescription);

  const readinessScore = [hasCv, hasRole, hasJob].filter(Boolean).length;

  const ctaHref = hasCv && hasRole ? "/dashboard" : "/onboarding";

  return (
    <main className="min-h-screen overflow-hidden bg-[#020817] text-white">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute left-1/2 top-[-180px] h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-blue-500/20 blur-[130px]" />
        <div className="absolute right-[-180px] top-[20%] h-[460px] w-[460px] rounded-full bg-cyan-400/10 blur-[130px]" />
        <div className="absolute bottom-[-220px] left-[-180px] h-[500px] w-[500px] rounded-full bg-purple-500/10 blur-[130px]" />
      </div>

      <div className="relative mx-auto flex min-h-screen max-w-7xl flex-col px-5 py-5 md:px-8">
        <header className="flex items-center justify-between rounded-3xl border border-white/10 bg-white/[0.06] px-4 py-3 shadow-2xl shadow-black/20 backdrop-blur-2xl md:px-5">
          <Link href="/" className="flex items-center gap-3">
            <Image
              src="/workzo_icon.png"
              alt="WorkZo AI"
              width={44}
              height={44}
              className="rounded-2xl"
              priority
            />

            <div>
              <p className="text-base font-semibold leading-tight">WorkZo AI</p>
              <p className="text-xs text-slate-400">Real Interview AI</p>
            </div>
          </Link>

          <nav className="hidden items-center gap-2 md:flex">
            <Link
              href="/onboarding"
              className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/10"
            >
              Setup
            </Link>

            <Link
              href="/dashboard"
              className="rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-slate-200 transition hover:bg-white/10"
            >
              Dashboard
            </Link>

            <Link
              href={ctaHref}
              className="rounded-2xl bg-blue-500 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/20 transition hover:bg-blue-400"
            >
              Start Interview
            </Link>
          </nav>

          <Link
            href={ctaHref}
            className="rounded-2xl bg-blue-500 px-4 py-2 text-sm font-semibold text-white md:hidden"
          >
            Start
          </Link>
        </header>

        <section className="grid flex-1 items-center gap-8 py-10 lg:grid-cols-[1.05fr_0.95fr] lg:py-14">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65 }}
          >
            <div className="inline-flex items-center gap-2 rounded-full border border-blue-400/20 bg-blue-500/10 px-4 py-2 text-xs font-medium text-blue-200 md:text-sm">
              <Sparkles className="h-4 w-4" />
              AI recruiter simulation based on your real CV
            </div>

            <h1 className="mt-6 max-w-5xl text-4xl font-black leading-[1.03] tracking-tight md:text-6xl lg:text-7xl">
              Face a real interview{" "}
              <span className="bg-gradient-to-r from-blue-400 via-cyan-300 to-white bg-clip-text text-transparent">
                before the real one.
              </span>
            </h1>

            <p className="mt-6 max-w-2xl text-base leading-8 text-slate-300 md:text-xl md:leading-9">
              Practice with an AI recruiter that reads your CV, asks sharp
              follow-ups, remembers weak answers, interrupts vague claims,
              detects CV mismatches, and gives honest feedback.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                href={ctaHref}
                className="group rounded-3xl bg-gradient-to-r from-blue-500 to-cyan-400 px-7 py-4 text-center text-base font-bold text-white shadow-2xl shadow-blue-500/25 transition hover:scale-[1.01] md:px-8 md:text-lg"
              >
                <span className="inline-flex items-center justify-center gap-2">
                  🎤 Start Real Interview
                  <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
                </span>
              </Link>

              <Link
                href="/onboarding"
                className="rounded-3xl border border-white/10 bg-white/5 px-7 py-4 text-center text-base font-semibold text-white transition hover:bg-white/10 md:px-8 md:text-lg"
              >
                Upload CV / Change setup
              </Link>
            </div>

            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              {[
                ["CV-aware", hasCv ? "Ready" : "Upload CV"],
                ["Role-focused", hasRole ? setup.targetRole : "Choose role"],
                ["Memory", `${safeCount(persistentPatterns)} patterns`],
              ].map(([label, value]) => (
                <div
                  key={label}
                  className="rounded-3xl border border-white/10 bg-white/[0.04] p-4 backdrop-blur-xl"
                >
                  <p className="text-xs uppercase tracking-wide text-slate-500">
                    {label}
                  </p>

                  <p className="mt-2 line-clamp-2 text-sm font-semibold text-slate-100">
                    {value}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 28, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.75, delay: 0.12 }}
            className="rounded-[38px] border border-white/10 bg-white/[0.06] p-4 shadow-2xl shadow-black/40 backdrop-blur-2xl md:p-6"
          >
            <div className="rounded-[32px] border border-white/10 bg-[#07111f] p-4 md:p-6">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm text-cyan-200">Live interview room</p>
                  <h2 className="mt-1 text-2xl font-bold md:text-3xl">
                    AI Recruiter is ready
                  </h2>
                </div>

                <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-500/10 text-3xl md:h-16 md:w-16">
                  👩🏻‍💼
                  <span className="absolute -right-1 -top-1 h-4 w-4 animate-pulse rounded-full bg-green-400 shadow-lg shadow-green-400/40" />
                </div>
              </div>

              <div className="mt-5 rounded-3xl border border-blue-400/20 bg-blue-500/10 p-4 md:p-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-blue-200">
                  Recruiter asks
                </p>

                <p className="mt-3 text-lg font-semibold leading-8 text-white md:text-xl">
                  “Tell me about yourself. Keep it relevant to this role — and
                  be specific.”
                </p>
              </div>

              <div className="mt-5 flex h-14 items-end gap-2">
                {[22, 38, 28, 52, 34, 46, 24, 42, 30, 55, 36, 26].map(
                  (height, index) => (
                    <span
                      key={index}
                      className="w-2 animate-pulse rounded-full bg-cyan-300"
                      style={{
                        height: `${height}px`,
                        animationDelay: `${index * 90}ms`,
                      }}
                    />
                  )
                )}
              </div>

              <div className="mt-5 grid gap-3 md:grid-cols-2">
                <div className="rounded-3xl border border-white/10 bg-black/20 p-4">
                  <p className="text-xs text-slate-400">Simulation behavior</p>

                  <div className="mt-3 space-y-2 text-sm text-slate-200">
                    <p>• Smart follow-ups</p>
                    <p>• Recruiter pressure</p>
                    <p>• CV mismatch checks</p>
                    <p>• Persistent memory</p>
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-black/20 p-4">
                  <p className="text-xs text-slate-400">Readiness</p>

                  <div className="mt-4 h-3 overflow-hidden rounded-full bg-white/10">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-500"
                      style={{ width: `${Math.max(12, readinessScore * 33)}%` }}
                    />
                  </div>

                  <p className="mt-3 text-sm text-slate-300">
                    {readinessScore}/3 setup signals ready
                  </p>
                </div>
              </div>

              <div className="mt-5 rounded-3xl border border-white/10 bg-black/20 p-4">
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div>
                    <p className="text-2xl font-bold">
                      {safeCount(answerHistory)}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">Answers</p>
                  </div>

                  <div>
                    <p className="text-2xl font-bold">
                      {safeCount(recruiterTrustHistory)}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">Trust points</p>
                  </div>

                  <div>
                    <p className="text-2xl font-bold">
                      {safeCount(persistentPatterns)}
                    </p>
                    <p className="mt-1 text-xs text-slate-500">Patterns</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        <section className="grid gap-4 pb-10 md:grid-cols-3">
          {[
            {
              icon: FileText,
              title: "1. Upload your CV",
              description:
                "WorkZo reads your real background before the interview starts.",
            },
            {
              icon: Mic,
              title: "2. Face AI recruiter",
              description:
                "Answer naturally by voice while the recruiter asks follow-ups.",
            },
            {
              icon: Gauge,
              title: "3. Get honest feedback",
              description:
                "See trust evolution, weaknesses, risks, and next improvements.",
            },
          ].map((item) => (
            <motion.div
              key={item.title}
              whileHover={{ y: -4 }}
              className="rounded-[30px] border border-white/10 bg-white/[0.04] p-5 backdrop-blur-xl"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-500/10 text-blue-200">
                <item.icon className="h-5 w-5" />
              </div>

              <h3 className="mt-4 text-lg font-bold">{item.title}</h3>

              <p className="mt-2 text-sm leading-6 text-slate-400">
                {item.description}
              </p>
            </motion.div>
          ))}
        </section>

        <section className="grid gap-4 pb-12 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="rounded-[32px] border border-white/10 bg-white/[0.04] p-6 backdrop-blur-xl">
            <div className="inline-flex rounded-full bg-cyan-500/10 px-3 py-1 text-xs text-cyan-200">
              Why it feels different
            </div>

            <h2 className="mt-4 text-3xl font-black md:text-4xl">
              Not interview questions.
              <span className="block text-blue-300">
                Recruiter psychology.
              </span>
            </h2>

            <p className="mt-4 text-sm leading-7 text-slate-400 md:text-base">
              WorkZo is designed to react like a real recruiter: skeptical when
              answers are vague, impressed when evidence is strong, and direct
              when the CV and spoken answer do not match.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {[
              {
                icon: Brain,
                title: "Memory engine",
                description: "Tracks repeated weaknesses across sessions.",
              },
              {
                icon: Zap,
                title: "Pressure moments",
                description: "Challenges vague answers and missing metrics.",
              },
              {
                icon: ShieldCheck,
                title: "CV contradiction checks",
                description: "Flags name, location, and background mismatch.",
              },
              {
                icon: UserRoundCheck,
                title: "Recruiter personalities",
                description: "HR, hiring manager, startup, corporate, pressure.",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="rounded-[28px] border border-white/10 bg-white/[0.04] p-5 backdrop-blur-xl"
              >
                <item.icon className="h-5 w-5 text-blue-300" />

                <h3 className="mt-4 font-bold">{item.title}</h3>

                <p className="mt-2 text-sm leading-6 text-slate-400">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
