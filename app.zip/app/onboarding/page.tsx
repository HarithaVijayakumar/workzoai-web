"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";
import {
  Briefcase,
  Upload,
  Globe,
  Sparkles,
  ShieldCheck,
  Brain,
  ArrowRight,
  FileText,
  Mic,
  Building2,
} from "lucide-react";

import { useInterviewStore } from "@/store/interviewStore";

const recruiterOptions = [
  {
    id: "friendly_hr",
    title: "Sarah · Friendly HR",
    description:
      "Warm, supportive, communication-focused recruiter personality.",
    mood: "Supportive",
    quote: "I'd love to understand how you work with people.",
    accent: "from-cyan-500/20 to-blue-500/20",
  },
  {
    id: "analytical_hiring_manager",
    title: "Daniel · Hiring Manager",
    description:
      "Evidence-driven recruiter focused on measurable impact.",
    mood: "Analytical",
    quote: "Can you prove the business impact behind that answer?",
    accent: "from-blue-500/20 to-indigo-500/20",
  },
  {
    id: "startup_recruiter",
    title: "Priya · Startup Recruiter",
    description:
      "Fast-paced recruiter looking for ownership and execution.",
    mood: "Fast-paced",
    quote: "What did YOU specifically own in that project?",
    accent: "from-purple-500/20 to-pink-500/20",
  },
  {
    id: "corporate_recruiter",
    title: "Markus · Corporate Recruiter",
    description:
      "Structured interviewer focused on clarity and professionalism.",
    mood: "Structured",
    quote: "Please keep the answer concise and relevant.",
    accent: "from-slate-500/20 to-zinc-500/20",
  },
  {
    id: "pressure_interviewer",
    title: "Alex · Pressure Interviewer",
    description:
      "Challenges weak answers and tests pressure handling.",
    mood: "Intense",
    quote: "Let me stop you there — I still don’t understand the impact.",
    accent: "from-red-500/20 to-orange-500/20",
  },
];

const marketOptions = [
  "Global",
  "Germany",
  "US",
  "UK",
  "India",
  "Netherlands",
];

const companyStyles = [
  "Realistic",
  "Startup",
  "Corporate",
  "Technical",
  "Consulting",
];

export default function OnboardingPage() {
  const router = useRouter();

  const { setup, updateSetup } = useInterviewStore();

  const [role, setRole] = useState(setup.targetRole || "");
  const [market, setMarket] = useState(setup.targetMarket || "Global");
  const [companyStyle, setCompanyStyle] = useState(
    setup.companyStyle || "Realistic"
  );

  const [recruiterPersonality, setRecruiterPersonality] = useState(
    setup.recruiterPersonality || "analytical_hiring_manager"
  );

  const [jobDescription, setJobDescription] = useState(
    setup.jobDescription || ""
  );

  const [cvText, setCvText] = useState(setup.cvText || "");
  const [cvFileName, setCvFileName] = useState("");
  const [cvError, setCvError] = useState("");
  const [isReadingCv, setIsReadingCv] = useState(false);

  const selectedRecruiter = recruiterOptions.find(
    (r) => r.id === recruiterPersonality
  );

  const readinessScore = useMemo(() => {
    let score = 0;

    if (role.trim()) score += 25;
    if (cvText.trim()) score += 35;
    if (jobDescription.trim()) score += 20;
    if (recruiterPersonality) score += 20;

    return score;
  }, [role, cvText, jobDescription, recruiterPersonality]);

  async function handleCvUpload(file: File | null) {
    if (!file) return;

    setCvError("");
    setCvFileName(file.name);
    setIsReadingCv(true);

    try {
      if (
        file.type === "text/plain" ||
        file.name.toLowerCase().endsWith(".txt")
      ) {
        const text = await file.text();
        setCvText(text);
        return;
      }

      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/cv", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("CV extraction failed");
      }

      const data = await response.json();

      const extractedText =
        data.text ||
        data.cvText ||
        data.content ||
        data.extractedText ||
        "";

      if (!extractedText) {
        throw new Error("No readable text found");
      }

      setCvText(extractedText);
      setCvError("");
    } catch (error) {
      console.error(error);

      setCvError(
        "Could not fully read this CV. Try a text-based PDF or paste the CV text manually."
      );
    } finally {
      setIsReadingCv(false);
    }
  }

  function handleStart() {
    updateSetup({
      targetRole: role.trim() || "General Role",
      targetMarket: market,
      companyStyle,
      recruiterPersonality,
      cvText,
      jobDescription,
    });

    router.push("/dashboard");
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#020817] text-white">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute left-1/2 top-[-180px] h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-blue-500/20 blur-[120px]" />
        <div className="absolute right-[-120px] top-[20%] h-[380px] w-[380px] rounded-full bg-cyan-400/10 blur-[120px]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-5 py-6 md:px-8 md:py-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-[36px] border border-white/10 bg-white/[0.05] p-6 shadow-2xl shadow-black/40 backdrop-blur-2xl md:p-10"
        >
          <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-blue-400/20 bg-blue-500/10 px-4 py-2 text-sm text-blue-200">
                <Sparkles className="h-4 w-4" />
                Real recruiter simulation setup
              </div>

              <h1 className="mt-6 max-w-4xl text-4xl font-black leading-[1.05] tracking-tight md:text-6xl">
                Prepare for a
                <span className="block bg-gradient-to-r from-blue-400 via-cyan-300 to-white bg-clip-text text-transparent">
                  real interview experience
                </span>
              </h1>

              <p className="mt-6 max-w-2xl text-base leading-8 text-slate-300 md:text-lg">
                WorkZo reads your CV, understands your target role,
                adapts to your country, and simulates recruiter behavior,
                pressure, interruptions, and follow-ups.
              </p>

              <div className="mt-8 grid gap-4 sm:grid-cols-3">
                {[
                  {
                    icon: Brain,
                    title: "Persistent memory",
                    desc: "Tracks recurring weaknesses",
                  },
                  {
                    icon: ShieldCheck,
                    title: "Recruiter realism",
                    desc: "Pressure + interruptions",
                  },
                  {
                    icon: Mic,
                    title: "Voice simulation",
                    desc: "Real-time AI interaction",
                  },
                ].map((item) => (
                  <div
                    key={item.title}
                    className="rounded-3xl border border-white/10 bg-black/20 p-4"
                  >
                    <item.icon className="h-5 w-5 text-blue-300" />

                    <p className="mt-3 font-semibold">{item.title}</p>

                    <p className="mt-1 text-sm leading-6 text-slate-400">
                      {item.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-[32px] border border-white/10 bg-[#07111f] p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-cyan-200">
                    Live recruiter preview
                  </p>

                  <h2 className="mt-1 text-2xl font-bold">
                    {selectedRecruiter?.title}
                  </h2>
                </div>

                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-500/10 text-2xl">
                  👩🏻‍💼
                </div>
              </div>

              <div
                className={`mt-5 rounded-3xl bg-gradient-to-br ${selectedRecruiter?.accent} p-[1px]`}
              >
                <div className="rounded-3xl bg-[#07111f] p-5">
                  <div className="flex items-center justify-between">
                    <span className="rounded-full bg-white/10 px-3 py-1 text-xs text-slate-300">
                      {selectedRecruiter?.mood}
                    </span>

                    <span className="text-xs text-slate-500">
                      AI recruiter active
                    </span>
                  </div>

                  <p className="mt-5 text-lg leading-8 text-white">
                    “{selectedRecruiter?.quote}”
                  </p>

                  <div className="mt-6 flex h-12 items-end gap-1">
                    {[18, 28, 22, 36, 20, 32, 18, 25].map((h, index) => (
                      <span
                        key={index}
                        className="w-2 animate-pulse rounded-full bg-cyan-300"
                        style={{
                          height: `${h}px`,
                          animationDelay: `${index * 120}ms`,
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-5 rounded-3xl border border-white/10 bg-black/20 p-5">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-slate-400">
                    Simulation readiness
                  </p>

                  <p className="text-sm font-semibold text-white">
                    {readinessScore}%
                  </p>
                </div>

                <div className="mt-3 h-3 overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-500"
                    style={{ width: `${readinessScore}%` }}
                  />
                </div>

                <div className="mt-5 grid grid-cols-2 gap-3 text-sm">
                  <div className="rounded-2xl bg-white/5 p-3">
                    <p className="text-slate-400">CV uploaded</p>
                    <p className="mt-1 font-semibold">
                      {cvText ? "Ready" : "Missing"}
                    </p>
                  </div>

                  <div className="rounded-2xl bg-white/5 p-3">
                    <p className="text-slate-400">Target role</p>
                    <p className="mt-1 font-semibold">
                      {role || "Missing"}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_0.9fr]">
          <section className="space-y-6">
            <div className="rounded-[32px] border border-white/10 bg-white/[0.05] p-6 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <Briefcase className="h-5 w-5 text-blue-300" />

                <p className="text-sm font-semibold text-blue-200">
                  1. Target role
                </p>
              </div>

              <input
                value={role}
                onChange={(event) => setRole(event.target.value)}
                placeholder="Example: Junior Data Analyst"
                className="mt-5 w-full rounded-2xl border border-white/10 bg-black/30 px-5 py-4 text-white outline-none placeholder:text-slate-500 focus:border-blue-400/60"
              />
            </div>

            <div className="rounded-[32px] border border-white/10 bg-white/[0.05] p-6 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <Upload className="h-5 w-5 text-blue-300" />

                <p className="text-sm font-semibold text-blue-200">
                  2. Upload your CV
                </p>
              </div>

              <p className="mt-3 text-sm leading-7 text-slate-400">
                Upload your CV so the recruiter can ask realistic,
                CV-aware interview questions.
              </p>

              <label className="mt-5 flex cursor-pointer flex-col items-center justify-center rounded-[28px] border border-dashed border-blue-400/30 bg-blue-500/10 px-6 py-10 text-center transition hover:bg-blue-500/15">
                <span className="text-xl font-semibold text-blue-100">
                  {isReadingCv ? "Reading CV..." : "Upload CV"}
                </span>

                <span className="mt-2 text-sm text-slate-400">
                  PDF or TXT recommended
                </span>

                <input
                  type="file"
                  accept=".pdf,.txt"
                  className="hidden"
                  onChange={(event) =>
                    handleCvUpload(event.target.files?.[0] || null)
                  }
                />
              </label>

              {cvFileName && (
                <div className="mt-4 rounded-2xl border border-green-400/20 bg-green-500/10 px-4 py-3 text-sm text-green-200">
                  Uploaded: {cvFileName}
                </div>
              )}

              {cvError && (
                <div className="mt-4 rounded-2xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">
                  {cvError}
                </div>
              )}

              <textarea
                value={cvText}
                onChange={(event) => setCvText(event.target.value)}
                placeholder="Or paste your CV text here..."
                rows={8}
                className="mt-5 w-full resize-none rounded-2xl border border-white/10 bg-black/30 px-5 py-4 text-sm leading-7 text-white outline-none placeholder:text-slate-500 focus:border-blue-400/60"
              />
            </div>

            <div className="rounded-[32px] border border-white/10 bg-white/[0.05] p-6 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <FileText className="h-5 w-5 text-blue-300" />

                <p className="text-sm font-semibold text-blue-200">
                  3. Job description
                </p>
              </div>

              <textarea
                value={jobDescription}
                onChange={(event) => setJobDescription(event.target.value)}
                placeholder="Paste the job description here..."
                rows={8}
                className="mt-5 w-full resize-none rounded-2xl border border-white/10 bg-black/30 px-5 py-4 text-sm leading-7 text-white outline-none placeholder:text-slate-500 focus:border-blue-400/60"
              />
            </div>
          </section>

          <section className="space-y-6">
            <div className="rounded-[32px] border border-white/10 bg-white/[0.05] p-6 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <Globe className="h-5 w-5 text-blue-300" />

                <p className="text-sm font-semibold text-blue-200">
                  4. Target market
                </p>
              </div>

              <div className="mt-5 flex flex-wrap gap-3">
                {marketOptions.map((option) => (
                  <button
                    key={option}
                    onClick={() => setMarket(option)}
                    className={`rounded-2xl px-4 py-3 text-sm font-medium transition ${
                      market === option
                        ? "bg-blue-500 text-white"
                        : "bg-white/10 text-slate-300 hover:bg-white/15"
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-[32px] border border-white/10 bg-white/[0.05] p-6 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <Building2 className="h-5 w-5 text-blue-300" />

                <p className="text-sm font-semibold text-blue-200">
                  5. Company style
                </p>
              </div>

              <div className="mt-5 flex flex-wrap gap-3">
                {companyStyles.map((option) => (
                  <button
                    key={option}
                    onClick={() => setCompanyStyle(option)}
                    className={`rounded-2xl px-4 py-3 text-sm font-medium transition ${
                      companyStyle === option
                        ? "bg-purple-500 text-white"
                        : "bg-white/10 text-slate-300 hover:bg-white/15"
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-[32px] border border-white/10 bg-white/[0.05] p-6 backdrop-blur-xl">
              <p className="text-sm font-semibold text-blue-200">
                6. Recruiter personality
              </p>

              <div className="mt-5 space-y-4">
                {recruiterOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setRecruiterPersonality(option.id)}
                    className={`w-full rounded-[28px] border p-5 text-left transition ${
                      recruiterPersonality === option.id
                        ? "border-blue-400/40 bg-blue-500/10"
                        : "border-white/10 bg-black/20 hover:bg-white/10"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="font-semibold text-white">
                          {option.title}
                        </p>

                        <p className="mt-2 text-sm leading-7 text-slate-400">
                          {option.description}
                        </p>
                      </div>

                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-xl">
                        👨🏻‍💼
                      </div>
                    </div>

                    <div className="mt-4 rounded-2xl bg-black/20 p-4 text-sm italic text-slate-300">
                      “{option.quote}”
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleStart}
              className="group flex w-full items-center justify-center gap-3 rounded-[28px] bg-gradient-to-r from-blue-500 to-cyan-400 px-6 py-5 text-lg font-bold text-white shadow-2xl shadow-blue-500/20 transition hover:scale-[1.01]"
            >
              🎤 Enter Interview Room

              <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
            </button>
          </section>
        </div>
      </div>
    </main>
  );
}
