"use client";

export type WorkZoEventName =
  | "landing_viewed"
  | "onboarding_viewed"
  | "cv_uploaded"
  | "jd_added"
  | "interview_started"
  | "interview_completed"
  | "voice_failed"
  | "video_failed"
  | "video_fallback_used"
  | "copilot_opened"
  | "copilot_action_used"
  | "results_viewed"
  | "weak_answer_retried"
  | "feedback_submitted"
  | "waitlist_joined";

export type WorkZoAnalyticsPayload = {
  event: WorkZoEventName;
  setupId?: string;
  role?: string;
  market?: string;
  recruiter?: string;
  mode?: "voice" | "video" | "standard" | "copilot";
  metadata?: Record<string, string | number | boolean | null | undefined>;
};

const STORAGE_KEY = "workzo-beta-analytics-events";

function safeNow() {
  return new Date().toISOString();
}

function getSessionId() {
  if (typeof window === "undefined") return "server";

  const key = "workzo-session-id";
  const existing = window.localStorage.getItem(key);
  if (existing) return existing;

  const sessionId =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `session_${Date.now()}_${Math.random().toString(16).slice(2)}`;

  window.localStorage.setItem(key, sessionId);
  return sessionId;
}

export function trackWorkZoLaunchEvent(payload: WorkZoAnalyticsPayload) {
  if (typeof window === "undefined") return;

  const item = {
    ...payload,
    sessionId: getSessionId(),
    timestamp: safeNow(),
    path: window.location.pathname,
    userAgent: navigator.userAgent,
  };

  try {
    const existing = JSON.parse(window.localStorage.getItem(STORAGE_KEY) || "[]") as unknown[];
    existing.push(item);
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(existing.slice(-500)));
  } catch {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify([item]));
  }

  if (process.env.NODE_ENV !== "production") {
    console.info("[WorkZo analytics]", item);
  }
}

export function readWorkZoLaunchEvents() {
  if (typeof window === "undefined") return [];

  try {
    return JSON.parse(window.localStorage.getItem(STORAGE_KEY) || "[]") as unknown[];
  } catch {
    return [];
  }
}
