// lib/workzoVoiceReliability.ts

export type VoiceFailureKind =
  | "microphone_blocked"
  | "audio_worklet_failed"
  | "connection_interrupted"
  | "assistant_unavailable"
  | "unknown";

export function classifyVoiceError(error: unknown): VoiceFailureKind {
  const message =
    error instanceof Error
      ? error.message
      : typeof error === "string"
        ? error
        : JSON.stringify(error || "");

  if (
    message.includes("NotAllowedError") ||
    message.includes("Permission denied") ||
    message.includes("microphone")
  ) {
    return "microphone_blocked";
  }

  if (
    message.includes("AudioWorkletNode") ||
    message.includes("WASM_OR_WORKER_NOT_READY") ||
    message.includes("Krisp")
  ) {
    return "audio_worklet_failed";
  }

  if (
    message.includes("Meeting has ended") ||
    message.includes("Signaling connection interrupted") ||
    message.includes("disconnect") ||
    message.includes("ejection")
  ) {
    return "connection_interrupted";
  }

  if (
    message.includes("assistant") ||
    message.includes("assistant ID") ||
    message.includes("public key")
  ) {
    return "assistant_unavailable";
  }

  return "unknown";
}

export function getVoiceFailureMessage(kind: VoiceFailureKind) {
  switch (kind) {
    case "microphone_blocked":
      return "Microphone access is blocked. Please allow microphone access or continue with fallback mode.";
    case "audio_worklet_failed":
      return "Voice processing could not start on this browser. Continuing with fallback mode.";
    case "connection_interrupted":
      return "Voice connection was interrupted. Continuing with fallback mode.";
    case "assistant_unavailable":
      return "Voice assistant is unavailable. Please check the voice setup or use fallback mode.";
    default:
      return "Standard voice could not start. Please retry or continue with fallback mode.";
  }
}

export async function requestMicrophoneAccess() {
  if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
    throw new Error("Microphone is not available in this browser.");
  }

  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

  // Stop preflight stream immediately. Vapi will request its own stream.
  stream.getTracks().forEach((track) => track.stop());

  return true;
}
