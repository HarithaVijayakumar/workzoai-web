import OpenAI from "openai";
import { NextResponse } from "next/server";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

type AnalyticsRequest = {
  events?: unknown[];
  results?: unknown[];
  feedback?: unknown[];
};

export async function POST(request: Request) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(
        {
          success: false,
          error: "OPENAI_API_KEY is missing.",
        },
        { status: 500 },
      );
    }

    const body = (await request.json()) as AnalyticsRequest;

    const events = JSON.stringify(body.events || []).slice(0, 8000);
    const results = JSON.stringify(body.results || []).slice(0, 6000);
    const feedback = JSON.stringify(body.feedback || []).slice(0, 4000);

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.25,
      max_tokens: 500,
      messages: [
        {
          role: "system",
          content:
            "You summarize WorkZo AI product analytics for the founder. Be concise, practical, and focused on launch decisions.",
        },
        {
          role: "user",
          content: `
Summarize these WorkZo analytics.

Return:
1. Top user behavior
2. Biggest drop-off risk
3. Most common interview weakness
4. One product improvement
5. One launch recommendation

EVENTS:
${events}

RESULTS:
${results}

FEEDBACK:
${feedback}
`.trim(),
        },
      ],
    });

    return NextResponse.json({
      success: true,
      summary:
        completion.choices[0]?.message?.content ||
        "No analytics summary generated.",
      model: "gpt-4o-mini",
    });
  } catch (error) {
    console.error("Analytics summary failed:", error);

    return NextResponse.json(
      {
        success: false,
        error: "Analytics summary failed.",
      },
      { status: 500 },
    );
  }
}
