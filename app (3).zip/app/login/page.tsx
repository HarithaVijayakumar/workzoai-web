"use client";

import Link from "next/link";
import {
  ArrowLeft,
  ArrowRight,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-[#050b14] text-white">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_left,rgba(59,130,246,0.18),transparent_34%),radial-gradient(circle_at_top_right,rgba(139,92,246,0.16),transparent_34%),linear-gradient(180deg,#050b14_0%,#08111f_55%,#050b14_100%)]" />

      <header className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-5 sm:px-6 lg:px-8">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-slate-300 hover:text-white">
          <ArrowLeft className="h-4 w-4" />
          Back to home
        </Link>

        <Link href="/demo" className="rounded-xl border border-white/10 px-4 py-2 text-sm font-black text-slate-200 hover:bg-white/[0.06]">
          Try Demo
        </Link>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[1fr_440px] lg:px-8 lg:py-20">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-blue-300/20 bg-blue-400/10 px-3 py-1.5 text-xs font-black uppercase tracking-[0.18em] text-blue-200">
            <LockKeyhole className="h-3.5 w-3.5" />
            Login
          </div>

          <h1 className="mt-6 text-4xl font-black tracking-tight sm:text-6xl">
            Accounts are coming soon.
          </h1>

          <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-300">
            WorkZo AI is currently in beta. You can use the interview flow without creating an account while we prepare secure login and saved profiles.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              href="/onboarding"
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-500 to-violet-600 px-6 py-4 text-base font-black"
            >
              Start Free Interview
              <ArrowRight className="h-5 w-5" />
            </Link>

            <Link
              href="/demo"
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] px-6 py-4 text-base font-black hover:bg-white/[0.08]"
            >
              Try Demo
            </Link>
          </div>
        </div>

        <section className="rounded-[2rem] border border-white/10 bg-[#091323]/90 p-6 shadow-2xl">
          <div className="grid h-14 w-14 place-items-center rounded-2xl bg-blue-400/10">
            <ShieldCheck className="h-7 w-7 text-blue-200" />
          </div>

          <h2 className="mt-5 text-2xl font-black">Beta access</h2>
          <p className="mt-3 leading-7 text-slate-300">
            For now, WorkZo stores interview setup and results locally in your browser. Secure cloud accounts will be added later.
          </p>

          <div className="mt-6 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <div className="flex items-center gap-3">
              <Mail className="h-5 w-5 text-violet-300" />
              <p className="font-black">Want updates?</p>
            </div>
            <p className="mt-2 text-sm leading-6 text-slate-400">
              Use the beta now and check back soon for saved accounts, premium plans, and interview history sync.
            </p>
          </div>

          <div className="mt-6 rounded-2xl border border-amber-300/15 bg-amber-400/[0.07] p-4">
            <div className="flex items-center gap-3">
              <Sparkles className="h-5 w-5 text-amber-200" />
              <p className="font-black">Launch-safe placeholder</p>
            </div>
            <p className="mt-2 text-sm leading-6 text-slate-300">
              This page prevents dead login links while keeping auth out of the critical launch path.
            </p>
          </div>
        </section>
      </section>
    </main>
  );
}
