"use client";

import Link from "next/link";
import { ArrowLeft, BarChart3, Clock3, Mic, RefreshCcw, Repeat2, TrendingUp, Users } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

type FounderEvent = {
  id?: string;
  eventName: string;
  createdAt: string;
  role?: string;
  recruiter?: string;
  company?: string;
  durationSeconds?: number;
  score?: number | null;
  trust?: number | null;
  verdict?: string;
  answers?: number;
  premiumVoiceEnabled?: boolean;
};

type InterviewResult = {
  id: string;
  savedAt: string;
  candidateName?: string;
  targetRole?: string;
  recruiterName?: string;
  durationSeconds?: number;
  score?: { overall?: number; trust?: number } | null;
  verdict?: { decision?: string; reason?: string };
  transcript?: Array<{ role: string; text: string }>;
};

function readJsonList<T>(key: string): T[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function formatDuration(seconds = 0) {
  if (!seconds) return "0m";
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}m ${secs}s`;
}

function average(values: number[]) {
  if (!values.length) return 0;
  return Math.round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

function uniqueCount(values: string[]) {
  return new Set(values.filter(Boolean)).size;
}

export default function FounderDashboardPage() {
  const [events, setEvents] = useState<FounderEvent[]>([]);
  const [results, setResults] = useState<InterviewResult[]>([]);

  const refresh = () => {
    setEvents(readJsonList<FounderEvent>("workzo_founder_events"));
    setResults(readJsonList<InterviewResult>("workzo_interview_results"));
  };

  useEffect(() => {
    refresh();
  }, []);

  const stats = useMemo(() => {
    const interviewStarted = events.filter((event) => event.eventName === "interview_started");
    const interviewSaved = events.filter((event) => event.eventName === "interview_saved");
    const viewed = events.filter((event) => event.eventName === "interview_room_viewed");

    const scores = results
      .map((result) => result.score?.overall)
      .filter((score): score is number => typeof score === "number");

    const completedResults = results.filter((result) => (result.transcript || []).some((item) => item.role === "candidate"));
    const avgDuration = average(results.map((result) => result.durationSeconds || 0).filter(Boolean));
    const avgScore = average(scores);

    return {
      roomViews: viewed.length,
      interviewsStarted: interviewStarted.length,
      interviewsCompleted: completedResults.length || interviewSaved.length,
      completionRate:
        interviewStarted.length > 0
          ? Math.round(((completedResults.length || interviewSaved.length) / interviewStarted.length) * 100)
          : 0,
      avgScore,
      avgDuration,
      returnUsers: uniqueCount(results.map((result) => result.candidateName || "")),
      vapiStarts: interviewStarted.filter((event) => event.premiumVoiceEnabled).length,
    };
  }, [events, results]);

  const recentResults = results.slice(0, 8);
  const recentEvents = events.slice(0, 10);

  return (
    <main className="min-h-screen bg-[#050b14] px-4 py-6 text-white sm:px-6">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link href="/dashboard" className="inline-flex items-center gap-2 text-sm text-slate-300 hover:text-white">
            <ArrowLeft className="h-4 w-4" />
            Back to dashboard
          </Link>

          <button
            type="button"
            onClick={refresh}
            className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-4 py-2 text-sm font-black text-slate-200 hover:bg-white/[0.08]"
          >
            <RefreshCcw className="h-4 w-4" />
            Refresh
          </button>
        </div>

        <section className="mt-6 rounded-3xl border border-white/10 bg-gradient-to-br from-blue-500/15 via-violet-500/10 to-white/[0.03] p-6">
          <p className="text-sm font-black uppercase tracking-[0.18em] text-blue-200">Founder Dashboard</p>
          <h1 className="mt-2 text-3xl font-black sm:text-4xl">WorkZo Usage Signals</h1>
          <p className="mt-2 max-w-3xl text-slate-300">
            Local founder analytics from this browser: room views, interview starts, completed sessions, scores, duration, and recent user flow.
          </p>
        </section>

        <section className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: "Room Views", value: stats.roomViews, icon: Users },
            { label: "Interviews Started", value: stats.interviewsStarted, icon: Mic },
            { label: "Completed", value: stats.interviewsCompleted, icon: BarChart3 },
            { label: "Completion Rate", value: `${stats.completionRate}%`, icon: TrendingUp },
            { label: "Average Score", value: stats.avgScore || "—", icon: BarChart3 },
            { label: "Average Duration", value: formatDuration(stats.avgDuration), icon: Clock3 },
            { label: "Return Users", value: stats.returnUsers, icon: Repeat2 },
            { label: "Premium Voice Starts", value: stats.vapiStarts, icon: Mic },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.label} className="rounded-3xl border border-white/10 bg-white/[0.03] p-5">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-slate-400">{item.label}</p>
                  <Icon className="h-5 w-5 text-blue-300" />
                </div>
                <p className="mt-3 text-3xl font-black">{item.value}</p>
              </div>
            );
          })}
        </section>

        <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_380px]">
          <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-5">
            <h2 className="text-xl font-black">Recent Interviews</h2>

            <div className="mt-4 space-y-3">
              {recentResults.map((result) => (
                <div key={result.id} className="rounded-2xl border border-white/10 bg-black/20 p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="font-black">{result.targetRole || "Interview Role"}</p>
                      <p className="mt-1 text-sm text-slate-400">
                        {result.recruiterName || "Recruiter"} · {formatDuration(result.durationSeconds || 0)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-slate-400">Score</p>
                      <p className="text-xl font-black text-blue-200">{result.score?.overall ?? "—"}</p>
                    </div>
                  </div>

                  <p className="mt-3 text-sm text-slate-300">
                    {result.verdict?.decision || "No verdict yet"}
                  </p>
                </div>
              ))}

              {!recentResults.length ? (
                <p className="rounded-2xl border border-white/10 bg-black/20 p-4 text-sm text-slate-400">
                  No saved interviews yet.
                </p>
              ) : null}
            </div>
          </section>

          <aside className="rounded-3xl border border-white/10 bg-white/[0.03] p-5">
            <h2 className="text-xl font-black">Recent Events</h2>

            <div className="mt-4 space-y-3">
              {recentEvents.map((event) => (
                <div key={event.id || `${event.eventName}-${event.createdAt}`} className="rounded-2xl border border-white/10 bg-black/20 p-3">
                  <p className="font-bold text-slate-200">{event.eventName}</p>
                  <p className="mt-1 text-xs text-slate-500">{new Date(event.createdAt).toLocaleString()}</p>
                  {event.role ? <p className="mt-2 text-sm text-slate-400">{event.role}</p> : null}
                </div>
              ))}

              {!recentEvents.length ? (
                <p className="rounded-2xl border border-white/10 bg-black/20 p-4 text-sm text-slate-400">
                  No tracked events yet.
                </p>
              ) : null}
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}
