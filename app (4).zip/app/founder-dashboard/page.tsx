export { default } from "../founder/page";
